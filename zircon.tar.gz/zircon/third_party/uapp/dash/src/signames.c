/* This file was automatically created by ./mksignames.
   Do not edit.  Edit support/mksignames.c instead. */

#include <signal.h>

/* A translation list so we can be polite to our users. */
const char *const signal_names[NSIG + 1] = {
    "EXIT",
    "HUP",
    "INT",
    "QUIT",
    "ILL",
    "TRAP",
    "ABRT",
    "EMT",
    "FPE",
    "KILL",
    "BUS",
    "SEGV",
    "SYS",
    "PIPE",
    "ALRM",
    "TERM",
    "URG",
    "STOP",
    "TSTP",
    "CONT",
    "CHLD",
    "TTIN",
    "TTOU",
    "IO",
    "XCPU",
    "XFSZ",
    "VTALRM",
    "PROF",
    "WINCH",
    "INFO",
    "USR1",
    "USR2",
    (char *)0x0
};
